package com.example.tarefassimples.ui.theme.model

import java.util.Date

class Tarefa {
        class Tarefa constructor(var titulo: String, var obs: String, var data: Date)

}