package com.example.tarefassimples.ui.theme.view

class widget {
}